
<?php include('admin_site_header.php'); ?>
<?php include('admin_site_sidebar.php'); ?>
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.html">Home</a>
					<i class="icon-angle-right"></i> 
				</li>
				
			</ul>
			
			<div class="row-fluid">
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>Dashboard</h2>
						
					</div>
					<div class="box-content" style="height:500px">
						
					
					</div>
				
					
					
				</div><!--/span-->

			</div><!--/row-->
    

	</div><!--/.fluid-container-->
	
			
		
<?php include('admin_site_footer.php'); ?>