$(function() {

	$('.accommodation').click(function(){
		alert('hello');
	});
}